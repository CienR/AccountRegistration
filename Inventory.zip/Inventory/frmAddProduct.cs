﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory
{
    public partial class frmAddProduct : Form
    {
        class NumberFormatException : Exception
        {
            public NumberFormatException(string quantity) : base(quantity)
            {

            }
        }
        class StringFormatException : Exception
        {
            public StringFormatException(string name) : base(name)
            {

            }
        }
        class CurrencyFormatException : Exception
        {
            public CurrencyFormatException(string quantity) : base(quantity)
            {

            }
        }


        private string _ProductName, _Category, _MfgDate, _ExpDate, _Description;
        private int _Quantity;
        private double _SellPrice;
        BindingSource showProductList;






        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            _ProductName = Product_Name(txtProductName.Text);
            _Category = cbCategory.Text;
            _MfgDate = dtPickerMfgDate.Value.ToString("yyy-MM-dd");
            _ExpDate = dtPickerExpDate.Value.ToString("yyy-MM-dd");
            _Description = richTxtDescription.Text;
            _Quantity = Quantity(txtQuantity.Text);
            _SellPrice = SellingPrice(txtSellPrice.Text);
            showProductList.Add(new ProductClass(_ProductName, _Category, _MfgDate, _ExpDate, _SellPrice, _Quantity, _Description));
            gridViewProductList.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            gridViewProductList.DataSource = showProductList;

        }


        public frmAddProduct()
        {
            InitializeComponent();
            showProductList = new BindingSource();

        }

        private void frmAddProduct_Load(object sender, EventArgs e)
        {


            String[] ListProductCategory = new String[]
            {
                "Beverages","Bread/Bakery","Canned/Jarred Goods","Dairy","Frozen Goods","Meat","Personal Care", "Other"
            };

            foreach (string variableName in ListProductCategory)
            {
                cbCategory.Items.Add(variableName);
            }



        }
        public string Product_Name(string name)
        {
            try
            {
                if (!Regex.IsMatch(name, @"^[a-zA-Z]+$"))
                {
                    throw new StringFormatException(name);
                }


            }
            catch (StringFormatException sfe)
            {
                MessageBox.Show("String, Invalid Format" + sfe.Message);
            }
            finally
            {
                Console.WriteLine("Input String only on the productname");
            }
            return name;

        }
        public int Quantity(string qty)
        {
            try
            {
                if (!Regex.IsMatch(qty, @"^[0-9]"))
                {
                    throw new NumberFormatException(qty);
                }


            }
            catch (NumberFormatException nfe)
            {
                MessageBox.Show("Number Format, Invalid Format" + nfe.Message);
            }
           
            return Convert.ToInt32(qty);

        }
        public double SellingPrice(string price)
        {
            try
            {
                if (!Regex.IsMatch(price.ToString(), @"^(\d*\.)?\d+$"))
                {
                    throw new CurrencyFormatException(price);
                }


            }
            catch (CurrencyFormatException cfe)
            {
                MessageBox.Show("Number in Decimal, Invalid Format" +
                    "" + cfe.Message);
            }
            
            return Convert.ToDouble(price);

        }
    }
}
